﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieApplicationAPI.Models
{
    public class Actor
    {
        public string ActorName { get; set; }

        public string ActorBio { get; set; }

        public string ActorDOB { get; set; }

        public string ActorGender { get; set; }
    }
}

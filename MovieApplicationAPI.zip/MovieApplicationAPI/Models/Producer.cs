﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieApplicationAPI.Models
{
    public class Producer
    {
        public string ProducerName { get; set; }

        public string ProducerBio { get; set; }

        public string ProducerDOB { get; set; }

        public string ProducerCompany { get; set; }

        public string ProducerGender { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieApplicationAPI.Models
{
    public class Movie
    {
        public string MovieName { get; set; }

        public string MovieReleaseDate { get; set; }

        public string MovieActors { get; set; }

        public string MovieProducers { get; set; }
    }
}

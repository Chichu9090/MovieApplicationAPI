﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MovieApplicationAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace MovieApplicationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieApplicationController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public MovieApplicationController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet, Route("MovieDetails")]
        public JsonResult MovieGet()
        {
            string query = @"
                                SELECT  MD.MovieName,CONVERT(CHAR(10),MD.MovieReleaseDate,126) AS [MovieReleaseDate]
						,STUFF((
                                SELECT ',' + ActorName
                                FROM Actor AD
								INNER JOIN MovieToActorMapping MAM ON MD.MovieID = MAM.MovieID
								WHERE AD.ActorID = MAM.ActorID
								ORDER BY AD.ActorName
                                FOR XML PATH('')
                            ),1,1,'') AS [MovieActors]
                        ,STUFF((
                                SELECT ',' + ProducerName
                                FROM Producer PD
								INNER JOIN MovieToProducerMapping MPM ON MD.MovieID = MPM.MovieID
								WHERE PD.ProducerID = MPM.ProducerID
								ORDER BY PD.ProducerName
                                FOR XML PATH('')
                            ),1,1,'') AS [MovieProducers]
                        FROM Movie MD
                            ";

            DataTable dt = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("MovieApplicationAppCon");
            SqlDataReader sqlDataReader;

            using (SqlConnection sqlConnection = new SqlConnection(sqlDataSource))
            {
                sqlConnection.Open();
                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    sqlDataReader = sqlCommand.ExecuteReader();
                    dt.Load(sqlDataReader);
                    sqlDataReader.Close();
                    sqlConnection.Close();
                }
            }

            return new JsonResult(dt);
        }

        [HttpGet, Route("ActorDetails")]
        public JsonResult ActorGet()
        {
            string query = @"
                                SELECT ActorName,ActorBio,CONVERT(char(10), ActorDOB,126),ActorGender
                                FROM dbo.Actor
                            ";

            DataTable dt = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("MovieApplicationAppCon");
            SqlDataReader sqlDataReader;

            using (SqlConnection sqlConnection = new SqlConnection(sqlDataSource))
            {
                sqlConnection.Open();
                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    sqlDataReader = sqlCommand.ExecuteReader();
                    dt.Load(sqlDataReader);
                    sqlDataReader.Close();
                    sqlConnection.Close();
                }
            }

            return new JsonResult(dt);
        }

        [HttpGet, Route("ProducerDetails")]
        public JsonResult ProducerGet()
        {
            string query = @"
                                SELECT ProducerName,ProducerBio,CONVERT(char(10), ProducerDOB,126),ProducerCompany,ProducerGender
                                FROM dbo.Producer
                            ";

            DataTable dt = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("MovieApplicationAppCon");
            SqlDataReader sqlDataReader;

            using (SqlConnection sqlConnection = new SqlConnection(sqlDataSource))
            {
                sqlConnection.Open();
                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    sqlDataReader = sqlCommand.ExecuteReader();
                    dt.Load(sqlDataReader);
                    sqlDataReader.Close();
                    sqlConnection.Close();
                }
            }

            return new JsonResult(dt);
        }

        [HttpPost, Route("CreateMovie")]
        public JsonResult MoviePost(Movie movie)
        {
            try
            {
                string query = @"
                                INSERT INTO dbo.Movie (MovieName,MovieReleaseDate,MovieActorList,MovieProducerList)
                                VALUES (@MovieName,CONVERT(DATETIME, @MovieReleaseDate, 120),@MovieActorList,@MovieProducerList)

                                INSERT MovieToActorMapping (MovieID,ActorID)
                                SELECT MovieID,AD.ActorID FROM Movie MD
                                INNER JOIN Actor AD ON  AD.ActorID IN (SELECT VALUE FROM STRING_SPLIT(MD.MovieActorList,','))
                                WHERE MD.MovieName = @MovieName

                                INSERT MovieToProducerMapping (MovieID,ProducerID)
                                SELECT MovieID,PD.ProducerID FROM Movie MD
                                INNER JOIN Producer PD ON  PD.ProducerID IN (SELECT value FROM STRING_SPLIT(MD.MovieProducerList,','))
                                WHERE MD.MovieName = @MovieName
                            ";

                DataTable dt = new DataTable();
                string sqlDataSource = _configuration.GetConnectionString("MovieApplicationAppCon");
                SqlDataReader sqlDataReader;

                using (SqlConnection sqlConnection = new SqlConnection(sqlDataSource))
                {
                    sqlConnection.Open();
                    using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                    {
                        sqlCommand.Parameters.AddWithValue("@MovieName", movie.MovieName);
                        sqlCommand.Parameters.AddWithValue("@MovieReleaseDate", movie.MovieReleaseDate);
                        sqlCommand.Parameters.AddWithValue("@MovieActorList", movie.MovieActors);
                        sqlCommand.Parameters.AddWithValue("@MovieProducerList", movie.MovieProducers);

                        sqlDataReader = sqlCommand.ExecuteReader();
                        dt.Load(sqlDataReader);
                        sqlDataReader.Close();
                        sqlConnection.Close();
                    }
                }

                return new JsonResult("Movie added Successfully");
            }
            catch (Exception e)
            {
                return new JsonResult(e.Message);
            }

        }

        [HttpPost, Route("CreateActor")]
        public JsonResult ActorPost(Actor actor)
        {
            try
            {
                string query = @"
                                INSERT INTO Actor (ActorName,ActorBio,ActorDOB,ActorGender)
                                VALUES (@ActorName,@ActorBio,CONVERT(DATETIME, @ActorDOB, 120),@ActorGender)
                            ";

                DataTable dt = new DataTable();
                string sqlDataSource = _configuration.GetConnectionString("MovieApplicationAppCon");
                SqlDataReader sqlDataReader;

                using (SqlConnection sqlConnection = new SqlConnection(sqlDataSource))
                {
                    sqlConnection.Open();
                    using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                    {
                        sqlCommand.Parameters.AddWithValue("@ActorName", actor.ActorName);
                        sqlCommand.Parameters.AddWithValue("@ActorBio", actor.ActorBio);
                        sqlCommand.Parameters.AddWithValue("@ActorDOB", actor.ActorDOB);
                        sqlCommand.Parameters.AddWithValue("@ActorGender", actor.ActorGender);

                        sqlDataReader = sqlCommand.ExecuteReader();
                        dt.Load(sqlDataReader);
                        sqlDataReader.Close();
                        sqlConnection.Close();
                    }
                }

                return new JsonResult("Actor added Successfully");
            }
            catch (Exception e)
            {
                return new JsonResult(e.Message);
            }
        }

        [HttpPost, Route("CreateProducer")]
        public JsonResult ProducerPost(Producer producer)
        {
            try
            {
                string query = @"
                                INSERT INTO Producer (ProducerName,ProducerBio,ProducerDOB,ProducerCompany,ProducerGender)
                                VALUES (@ProducerName,@ProducerBio,CONVERT(DATETIME, @ProducerDOB, 120),@ProducerCompany,@ProducerGender)
                            ";

                DataTable dt = new DataTable();
                string sqlDataSource = _configuration.GetConnectionString("MovieApplicationAppCon");
                SqlDataReader sqlDataReader;

                using (SqlConnection sqlConnection = new SqlConnection(sqlDataSource))
                {
                    sqlConnection.Open();
                    using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                    {
                        sqlCommand.Parameters.AddWithValue("@ProducerName", producer.ProducerName);
                        sqlCommand.Parameters.AddWithValue("@ProducerBio", producer.ProducerBio);
                        sqlCommand.Parameters.AddWithValue("@ProducerDOB", producer.ProducerDOB);
                        sqlCommand.Parameters.AddWithValue("@ProducerCompany", producer.ProducerCompany);
                        sqlCommand.Parameters.AddWithValue("@ProducerGender", producer.ProducerGender);

                        sqlDataReader = sqlCommand.ExecuteReader();
                        dt.Load(sqlDataReader);
                        sqlDataReader.Close();
                        sqlConnection.Close();
                    }
                }

                return new JsonResult("Producer added Successfully");
            }
            catch (Exception e)
            {
                return new JsonResult(e.Message);
            }
        }

        [HttpPut, Route("UpdateMovie")]
        public JsonResult MovieUpdatePut(Movie movie)
        {
            string query = @"
                                UPDATE dbo.Movie 
                                SET MovieName = @MovieName,
                                    MovieReleaseDate = @MovieReleaseDate,
                                    MovieActorList = @MovieActorList,
                                    MovieProducerList = @MovieProducerList
                                WHERE MovieName = @MovieName
                                
                               DECLARE @MovieID INT;
                               SELECT @MovieID = MovieID
                               FROM Movie WHERE MovieName = @MovieName
                        
                               DELETE FROM MovieToActorMapping WHERE MovieID = @MovieID
                               DELETE FROM MovieToProducerMapping WHERE MovieID = @MovieID
                                
                               INSERT MovieToActorMapping (MovieID,ActorID)
                               SELECT MovieID,AD.ActorID FROM Movie MD
                               INNER JOIN Actor AD ON  AD.ActorID IN (SELECT VALUE FROM STRING_SPLIT(MD.MovieActorList,','))
                               WHERE MD.MovieName = @MovieName

                               INSERT MovieToProducerMapping (MovieID,ProducerID)
                               SELECT MovieID,PD.ProducerID FROM Movie MD
                               INNER JOIN Producer PD ON  PD.ProducerID IN (SELECT value FROM STRING_SPLIT(MD.MovieProducerList,','))
                               WHERE MD.MovieName = @MovieName
                            ";

            DataTable dt = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("MovieApplicationAppCon");
            SqlDataReader sqlDataReader;

            using (SqlConnection sqlConnection = new SqlConnection(sqlDataSource))
            {
                sqlConnection.Open();
                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    sqlCommand.Parameters.AddWithValue("@MovieName", movie.MovieName);
                    sqlCommand.Parameters.AddWithValue("@MovieReleaseDate", movie.MovieReleaseDate);
                    sqlCommand.Parameters.AddWithValue("@MovieActorList", movie.MovieActors);
                    sqlCommand.Parameters.AddWithValue("@MovieProducerList", movie.MovieProducers);

                    sqlDataReader = sqlCommand.ExecuteReader();
                    dt.Load(sqlDataReader);
                    sqlDataReader.Close();
                    sqlConnection.Close();
                }
            }

            return new JsonResult("Movie updated successfully");
        }


    }
}

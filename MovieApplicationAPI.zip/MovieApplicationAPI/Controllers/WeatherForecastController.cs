﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieApplicationAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public string Get()
        {
            string welComeMessage = @" Wel-Come to Movie Application API
                                       
                                       Below API Methods are supported :
                                       GET Method : http://localhost:57520/api/MovieApplication/MovieDetails
                                       GET Method : http://localhost:57520/api/MovieApplication/ActorDetails
                                       GET Method : http://localhost:57520/api/MovieApplication/ProducerDetails


                                       POST Method : http://localhost:57520/api/MovieApplication/CreateMovie
                                       Body details need to be passed like below JSON :
                                       {
                                                ""MovieName"": ""Thor 2"",
                                                ""MovieReleaseDate"": ""2021-11-13"",
                                                ""MovieActors"": ""1"",
                                                ""MovieProducers"": ""1,2""
                                       }

                                       POST Method : http://localhost:57520/api/MovieApplication/CreateActor
                                       Body details need to be passed like below JSON :
                                       {
                                                ""ActorName"": ""Actor 1"",
                                                ""ActorBio"": ""Actor 1 Bio"",
                                                ""ActorDOB"": ""2021-11-13"",
                                                ""ActorGender"": ""Male""
                                       }

                                       POST Method : http://localhost:57520/api/MovieApplication/CreateProducer
                                       Body details need to be passed like below JSON :
                                       {
                                                ""ProducerName"": ""Producer 1"",
                                                ""ProducerBio"": ""Producer 1 Bio"",
                                                ""ProducerDOB"": ""2021-11-13"",
                                                ""ProducerCompany"": ""Producer Company"",
                                                ""ProducerGender"": ""Male""
                                       }

                                       PUT Method : http://localhost:57520/api/MovieApplication/UpdateMovie
                                       Body details need to be passed like below JSON :
                                       {
                                                ""MovieName"": ""Thor 2"",
                                                ""MovieReleaseDate"": ""2021-11-13"",
                                                ""MovieActors"": ""1"",
                                                ""MovieProducers"": ""1,2""
                                       }
                                    ";
            return (welComeMessage);
        }
    }
}
